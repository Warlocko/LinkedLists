#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"

int main()
{
  item * theList;
  loadList(&theList);
  int option;
  do{
        puts("What would you like to do?");
        puts("1. Print the list.");
        puts("2. Print the oldest person");
        puts("3. Print the youngest person");
        puts("4. Print the average of ages");
        puts("5. Print all names that start with a given letter");
        puts("6. End program");
        scanf("%d", &option);
  switch(option){
    case 1:
    iterateList(theList);
    break;
    case 2:
    printOldest(theList);
    break;
    case 3:
    printYoungest(theList);
    break;
    case 4:
    avgAge(theList);
    break;
  }

  }while(option != 6);
  return 0;
}